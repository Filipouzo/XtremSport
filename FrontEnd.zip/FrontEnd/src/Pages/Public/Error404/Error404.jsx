import React from 'react';

const Error404 = () => {
    return (
        <div>
            <p>ERROR</p>
        </div>
    );
};

export default Error404;