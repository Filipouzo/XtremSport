export { default as Home } from "./Home/Home";
export { default as Contact } from "./Contact/Contact";
export { default as Sport } from "./Sport/Sport";
export { default as Error404 } from "./Error404/Error404";